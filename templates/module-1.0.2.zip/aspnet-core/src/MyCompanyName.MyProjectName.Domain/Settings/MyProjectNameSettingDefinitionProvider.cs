﻿using Volo.Abp.Settings;

namespace MyCompanyName.MyProjectName.Settings
{
    public class MyProjectNameSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            /* Define module settings here.
             * Use names from MyProjectNameSettings class.
             */
        }
    }
}