import { Component } from '@angular/core';

@Component({
  selector: 'my-project-name-settings',
  template: `
    <h3>MyProjectName Settings</h3>
  `,
})
export class MyProjectNameSettingsComponent {}
