export * from './lib/components/my-project-name-settings.component';
export * from './lib/services/my-project-name-config.service';
export * from './lib/my-project-name-config.module';
