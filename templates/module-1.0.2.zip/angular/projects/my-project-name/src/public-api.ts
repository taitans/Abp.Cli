export * from './lib/components/my-project-name.component';
export * from './lib/my-project-name.module';
