import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-my-project-name',
  template: `
    <p>
      my-project-name works!
    </p>
  `,
  styles: []
})
export class MyProjectNameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
