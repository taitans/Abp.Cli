import { NgModule } from '@angular/core';
import { TenantManagementModule } from '@abp/ng.tenant-management';

@NgModule({
  imports: [TenantManagementModule],
})
export class TenantManagementWrapperModule {}
