import { NgModule } from '@angular/core';
import { AccountModule } from '@abp/ng.account';

@NgModule({
  imports: [AccountModule],
})
export class AccountWrapperModule {}
