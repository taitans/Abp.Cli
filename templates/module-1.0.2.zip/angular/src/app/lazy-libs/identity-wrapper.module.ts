import { NgModule } from '@angular/core';
import { IdentityModule } from '@abp/ng.identity';

@NgModule({
  imports: [IdentityModule],
})
export class IdentityWrapperModule {}
