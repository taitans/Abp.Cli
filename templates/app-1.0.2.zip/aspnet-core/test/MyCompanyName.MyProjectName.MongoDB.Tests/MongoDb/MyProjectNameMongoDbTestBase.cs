﻿namespace MyCompanyName.MyProjectName.MongoDB
{
    public abstract class MyProjectNameMongoDbTestBase : MyProjectNameTestBase<MyProjectNameMongoDbTestModule> 
    {

    }
}
