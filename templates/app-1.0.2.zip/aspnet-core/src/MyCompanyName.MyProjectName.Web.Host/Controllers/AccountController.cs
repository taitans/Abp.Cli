﻿using Volo.Abp.AspNetCore.Mvc.Authentication;

namespace MyCompanyName.MyProjectName.Web.Controllers
{
    public class AccountController : ChallengeAccountController
    {

    }
}