import { NgModule } from '@angular/core';
import { SettingManagementModule } from '@abp/ng.setting-management';

@NgModule({
  imports: [SettingManagementModule],
})
export class SettingManagementWrapperModule {}
